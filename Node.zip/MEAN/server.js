var express=require('express');
var logger=require('express');
var bodyParser=require('body-parser');
var router=express.Router();
var indexRouter=express.Router();
var app=express();


var mongoose=require('mongoose');
mongoose.connect("mongodb://localhost/testdb");
var db=mongoose.connection;
db.on('error',console.error.bind(console,'connection error'));
db.once('open',()=>console.log("connected to DB"));

var foodSchema=mongoose.Schema({
            name:"String",
            color:"String"
});

var Food=mongoose.model('Food',foodSchema);
app.use('/api',router);
app.use('/',indexRouter);

router.route('/foods')
.post(function(req,res){
    var name=req.body.name;
    var color=req.body.color;

    var food= new Food({
      name:name,
      color:color
    });
      food.save(function(err,food){
        if(err) res.send({error:err});
        res.json({message:'food added', food:food});
      })
})
.get(function(req,res){
  Food.find({},function(err,foods){
    if(err) res.send({error:err});
    res.json(foods);
  });
});

router.route('/foods/:id')
.post(function(req,res){
  var id=req.params.id;
  food.findById(id,function(err,food){
    if(err) res.send({error:err});
    food.name=req.body.name;
    food.color=req.body.color;
    food.save(function(err,food){
      if(err) res.send({error:err});
      res.json({message:'food item updated',food:food});

    })
});
})
.put(function(req,res){
  var id=req.params.id;
  food.findById(id,function(err,food){
    if(err) res.send({error:err});
    food.name=req.body.name;
    food.color=req.body.color;
    food.save(function(err,food){
      if(err) res.send({error:err});
      res.json({message:'food item updated',food:food});

    })
});

})
.delete(function(req,res){

  var id=req.params.id;
  food.findById(id,function(err,food){
    if(err) res.send({error:err});

    Food.remove({_id:id},function(err,food){
      if(err) res.send({error:err});
      res.json({message:'food removed'});

    })
  });

})
.get(function(req,res){
  var id=req.params.id;
  Food.findById(id,function(err,food){
    if(err) res.send({error:err});
    res.json(food);
  });
});

indexRouter.route('/*',function(req,res){
  res.end("u r redirected to main page");
});

app.use(logger('dev'));
app.use(bodyParser.urlencoded({'extended':'true'}));
app.use(bodyParser.json());



var port=1234;
app.listen(port,()=>console.log("u r listening to 1234"));
