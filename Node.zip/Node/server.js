var debug=require('debug')('demo');
var express=require('express');
//var routes=require('./routes');
var router=express.Router();
var fruitsRouter=express.Router();
var app=express();
app.use(express.static(__dirname+'/public'));
router.get('/about',function(req,res){
  res.end("this is all about ");
});
fruitsRouter.get('/about',function(req,res){res.end("this is all about fruits")});
app.use('/',router);
app.use('/fruits',fruitsRouter);
app.get('/home',(req,res)=>res.send('Hi, This is ur home page'));
//app.get('/fruits',routes.fruits);
//app.get('/veg',routes.veg);
app.get('*',function(req,res,next){
  var err=new Error('failed to load resource');
  err.status=404;
  next(err);
});
app.use(function(err,req,res,next){
  if(err.status==404)
  {
    console.log("404 error");
    res.status(404);
    res.send("resources not available");
    return;
  }
  else {
    return next();
  }
});
app.listen(5000,()=>console.log('u r listening to 5000 localhost'));
