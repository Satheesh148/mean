var routes={
   //fruits:()=>res.end("welcome to fruits page"), //short form
   veg:function(req,res){
     res.end("welcome to veg page");
   }

};
module.exports=routes;
