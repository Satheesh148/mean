console.log("creating restful server");
var express=require('express');
var mongoose=require('mongoose');
var bodyParser=require('body-parser');
//-----------------
mongoose.connect('mongodb://localhost/mydemodb');
var db=mongoose.connection;
db.on('error',console.error.bind(console,'connection error'));
//create schema
var islandSchema=mongoose.Schema({
  id: String,
  name:String,
  language:String
});

//create model that uses schema
var Island=mongoose.model('Island',islandSchema);
//-----------------
var app=express();
var router=express.Router();
router.route('/islands')
.get(function(req,res){
Island.find({},function(err,islands){
  if(err) res.send({error:err});
  res.json(islands);
});
})
.post(function(req,res){
         var id=req.body.id;
         var name=req.body.name;
         var language=req.body.language;
         var island =new Island({
                   id:id,
                   name:name,
                   language:language
         });
         island.save(function(err,island){
           if(err) res.send({error:err});
           res.json({message:'Island Added',island:island});
         });
})

router.route('/islands/:id')
.get(function(req,res){
            var id=req.params.id;
            Island.findById(id,function(err,island){
              if(err) res.send({error:err});
              res.json(island);

});
})
.post(function(req,res){

})
.put(function(req,res){

})
.delete(function(req,res){
          var id=req.params.id;
          Island.findById(id,function(err,island){
            if(err)res.send({error:err});
            Island.remove({_id:id},function(err,island){
              if(err)res.send({error:err});
              res.json({message:'island deleted'});
            });
          });
})
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use('/api',router);
//----------------
var port=1234;
app.listen(port,function(){
  console.log("You are listening to restful web server @1234");
});
